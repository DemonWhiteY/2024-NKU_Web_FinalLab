document.addEventListener("DOMContentLoaded", function () {
  const num1 = document.getElementById("num1");
  const num2 = document.getElementById("num2");
  const operation = document.getElementById("operation");
  const calculateButton = document.getElementById("calculate");
  const result = document.getElementById("result");

  calculateButton.addEventListener("click", function () {
    const num1Value = parseFloat(num1.value);
    const num2Value = parseFloat(num2.value);
    const operationValue = operation.value;
    let resultValue;

    switch (operationValue) {
      case "+":
        resultValue = num1Value + num2Value;
        break;
      case "-":
        resultValue = num1Value - num2Value;
        break;
      case "*":
        resultValue = num1Value * num2Value;
        break;
      case "/":
        if (num2Value === 0) {
          result.textContent = "Error: Division by zero";
          return;
        }
        resultValue = num1Value / num2Value;
        break;
      default:
        result.textContent = "Error: Invalid operation";
        return;
    }

    result.textContent = `Result: ${resultValue}`;
  });
});
