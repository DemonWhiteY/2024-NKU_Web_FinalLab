let countdownInterval;

document.getElementById('start').addEventListener('click', () => {
    const duration = parseInt(document.getElementById('duration').value, 10);
    if (!isNaN(duration) && duration > 0) {
        startCountdown(duration);
    }
});

document.getElementById('stop').addEventListener('click', () => {
    stopCountdown();
});

function startCountdown(duration) {
    // Clear any existing interval
    clearInterval(countdownInterval);

    const endTime = Date.now() + duration * 1000;

    countdownInterval = setInterval(() => {
        const remainingTime = Math.max(0, endTime - Date.now());
        updateCountdownDisplay(remainingTime);

        if (remainingTime <= 0) {
            clearInterval(countdownInterval);
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                chrome.tabs.remove(tabs[0].id);
            });
        }
    }, 1000);

    chrome.runtime.sendMessage({ action: 'startTimer', duration: duration });
}

function stopCountdown() {
    clearInterval(countdownInterval);
    document.getElementById('countdown').textContent = '00:00';
    chrome.runtime.sendMessage({ action: 'stopTimer' });
}

function updateCountdownDisplay(remainingTime) {
    const minutes = Math.floor(remainingTime / 60000);
    const seconds = Math.floor((remainingTime % 60000) / 1000);
    document.getElementById('countdown').textContent =
        `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}
