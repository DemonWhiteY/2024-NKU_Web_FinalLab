let countdownTimer;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'startTimer') {
        const duration = message.duration * 1000; // Convert seconds to milliseconds
        clearTimeout(countdownTimer);
        countdownTimer = setTimeout(() => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                chrome.tabs.remove(tabs[0].id);
            });
        }, duration);
    } else if (message.action === 'stopTimer') {
        clearTimeout(countdownTimer);
    }
});
